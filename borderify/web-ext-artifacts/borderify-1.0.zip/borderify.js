document.body.style.border = "10px solid green";
